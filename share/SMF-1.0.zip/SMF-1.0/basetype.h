#ifndef BASETYPE_H_80eboy
#define BASETYPE_H_80eboy

typedef unsigned char u8;
typedef          char s8;


#endif // BASETYPE_H

