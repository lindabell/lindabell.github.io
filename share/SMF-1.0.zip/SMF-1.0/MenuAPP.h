#ifndef _MENUAPP_H_80eboy
#define _MENUAPP_H_80eboy
#include "basetype.h"
#include "Menu.h"

extern const struct PAGE mainPage;

extern const struct PAGE mainPage_Item1Page;


#endif
