#ifndef _MCU_H_80eboy
#define _MCU_H_80eboy

void MCU_Init(void);
void MCU_While(void);
#endif

