#ifndef _USART1_H_BAB
#define _USART1_H_BAB

#ifdef __cplusplus
extern "C"{
#endif


void usart1_configure(void);

#ifdef __cplusplus
}
#endif
#endif
