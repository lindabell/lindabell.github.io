#ifndef _LED_H_BAB
#define _LED_H_BAB

#define LED_OFF 	GPIO_SetBits(GPIOA,GPIO_Pin_4)
#define LED_ON 		GPIO_ResetBits(GPIOA,GPIO_Pin_4)

void led_configure(void);

#endif
