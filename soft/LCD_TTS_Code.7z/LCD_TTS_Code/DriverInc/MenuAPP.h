#ifndef _MenuAPP_H_BAB
#define _MenuAPP_H_BAB

#include "Menu.h"
#include "SMSAPP.h"

extern const struct PAGE mainPage;

extern const struct PAGE mainPage_Item1Page;



#endif
